Σιώτης Κωνσταντίνος
ΑΜ: 1115201700140

Η υλοποίηση αναπτύχθηκε σε windows 10 με wsl2 ubuntu subsystem με χρήση vscode.
Έτρεξαν σωστά όλα τα test cases του piazza.

To compile:
    make

To produce java code:
   make run

   prints out: instructions
   
To cleanup files:
   make clean
